module.exports = {
    ignoreFiles: [
        'node_modules/**',
        'src/*.ts',
        'src/**/*.ts',
        'web-ext-artifacts/**',
        'package.json',
        'package-lock.json',
        '.gitignore',
        'tsconfig.json',
    ]
}